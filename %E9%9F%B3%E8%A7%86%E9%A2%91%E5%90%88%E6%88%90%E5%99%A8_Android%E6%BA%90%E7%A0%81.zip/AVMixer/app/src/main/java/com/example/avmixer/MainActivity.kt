package com.example.avmixer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegSession
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private enum class Mode { IMAGE_AUDIO, VIDEO_AUDIO }
    private var mode = Mode.IMAGE_AUDIO
    private var visualUri: Uri? = null
    private var audioUri: Uri? = null
    private var visualLabel: String = "尚未选择"
    private var audioLabel: String = "尚未选择"
    private lateinit var visualText: TextView
    private lateinit var audioText: TextView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var makeButton: Button
    private val executor = Executors.newSingleThreadExecutor()
    private var pendingOutput: File? = null

    private val pickVisual = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            visualUri = uri
            visualLabel = displayName(uri)
            visualText.text = "已选：$visualLabel"
        }
    }
    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            audioUri = uri
            audioLabel = displayName(uri)
            audioText.text = "已选：$audioLabel"
        }
    }
    private val saveOutput = registerForActivityResult(ActivityResultContracts.CreateDocument("video/x-matroska")) { uri ->
        val source = pendingOutput
        if (uri != null && source != null && source.exists()) {
            executor.execute {
                try {
                    contentResolver.openOutputStream(uri)?.use { out -> source.inputStream().use { it.copyTo(out) } }
                    runOnUiThread { status.text = "已保存到所选位置"; progress.visibility = View.GONE }
                } catch (e: Exception) {
                    runOnUiThread { status.text = "保存失败：${e.message}"; progress.visibility = View.GONE }
                }
            }
        } else {
            status.text = "已取消保存"
            progress.visibility = View.GONE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            setBackgroundColor(0xFFF7F7F7.toInt())
        }
        val title = TextView(this).apply {
            text = "音视频合成器"
            textSize = 25f
            setTextColor(0xFF171717.toInt())
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(title, lp(-1, -2))
        val subtitle = TextView(this).apply {
            text = "本地处理 · 不上传文件 · FFmpeg"
            textSize = 13f
            setTextColor(0xFF666666.toInt())
            setPadding(0, dp(5), 0, dp(18))
        }
        root.addView(subtitle, lp(-1, -2))

        val group = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val imageMode = RadioButton(this).apply { id = View.generateViewId(); text = "图片 + 音频 → 视频"; isChecked = true }
        val videoMode = RadioButton(this).apply { id = View.generateViewId(); text = "视频 + 音频 → 新视频" }
        group.addView(imageMode); group.addView(videoMode)
        group.setOnCheckedChangeListener { _, checked ->
            mode = if (checked == imageMode.id) Mode.IMAGE_AUDIO else Mode.VIDEO_AUDIO
            visualLabel = "尚未选择"; visualUri = null
            visualText.text = visualLabel
        }
        root.addView(group, lp(-1, -2))

        visualText = addPicker(root, "画面文件", visualLabel) { pickVisual.launch(arrayOf("*/*")) }
        audioText = addPicker(root, "音频文件", audioLabel) { pickAudio.launch(arrayOf("*/*")) }

        val hint = TextView(this).apply {
            text = "支持常见格式：MP4、MKV、MOV、AVI、WEBM、FLAC、MP3、WAV、AAC、M4A、OGG、OPUS、JPG、PNG、WEBP 等。实际兼容性取决于文件内部编码。"
            textSize = 12f
            setTextColor(0xFF666666.toInt())
            setPadding(0, dp(12), 0, dp(12))
        }
        root.addView(hint, lp(-1, -2))

        makeButton = Button(this).apply {
            text = "开始合成"
            setOnClickListener { startMerge() }
        }
        root.addView(makeButton, lp(-1, dp(52)))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            visibility = View.GONE
            isIndeterminate = true
        }
        root.addView(progress, lp(-1, dp(6)))
        status = TextView(this).apply {
            text = "请选择画面文件和音频文件"
            textSize = 13f
            setTextColor(0xFF444444.toInt())
            setPadding(0, dp(12), 0, 0)
        }
        root.addView(status, lp(-1, -2))
        val note = TextView(this).apply {
            text = "输出：MKV（兼容性优先）。视频模式默认保留视频流并替换音轨；图片模式生成 30 fps 视频。"
            textSize = 11f
            setTextColor(0xFF777777.toInt())
            setPadding(0, dp(18), 0, 0)
        }
        root.addView(note, lp(-1, -2))

        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun addPicker(parent: LinearLayout, heading: String, initial: String, action: () -> Unit): TextView {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        val label = TextView(this).apply {
            text = heading
            textSize = 14f
            setTextColor(0xFF222222.toInt())
        }
        val selected = TextView(this).apply {
            text = initial
            textSize = 12f
            setTextColor(0xFF666666.toInt())
            setPadding(0, dp(4), 0, dp(8))
        }
        val button = Button(this).apply {
            text = "选择文件"
            setOnClickListener { action() }
        }
        card.addView(label); card.addView(selected); card.addView(button)
        val params = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        parent.addView(card, params)
        if (heading == "画面文件") visualText = selected else audioText = selected
        return selected
    }

    private fun startMerge() {
        val v = visualUri
        val a = audioUri
        if (v == null || a == null) {
            status.text = "请先选择画面文件和音频文件"
            return
        }
        makeButton.isEnabled = false
        progress.visibility = View.VISIBLE
        status.text = "正在准备文件…"
        executor.execute {
            try {
                val visual = copyToCache(v, "visual")
                val audio = copyToCache(a, "audio")
                val output = File(cacheDir, "merged_${System.currentTimeMillis()}.mkv")
                pendingOutput = output
                val args = if (mode == Mode.IMAGE_AUDIO) {
                    listOf("-y", "-loop", "1", "-framerate", "30", "-i", visual.absolutePath,
                        "-i", audio.absolutePath, "-map", "0:v:0", "-map", "1:a:0",
                        "-c:v", "mpeg4", "-q:v", "3", "-c:a", "copy", "-shortest",
                        "-f", "matroska", output.absolutePath)
                } else {
                    listOf("-y", "-i", visual.absolutePath, "-i", audio.absolutePath,
                        "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", "-c:a", "copy",
                        "-shortest", "-f", "matroska", output.absolutePath)
                }
                runOnUiThread { status.text = "正在合成…请保持应用在前台" }
                FFmpegKit.executeWithArgumentsAsync(args.toTypedArray(), { session ->
                    runOnUiThread {
                        makeButton.isEnabled = true
                        if (ReturnCode.isSuccess(session.returnCode) && output.exists() && output.length() > 0) {
                            status.text = "合成完成，选择保存位置"
                            saveOutput.launch("合成视频.mkv")
                        } else {
                            status.text = "合成失败：${session.failStackTrace ?: session.allLogsAsString.takeLast(500)}"
                            progress.visibility = View.GONE
                        }
                    }
                }, { log ->
                    // Keep detailed FFmpeg logs out of the main screen; surfaced on failure.
                }, { stats ->
                    runOnUiThread { status.text = "正在合成… ${stats.time / 1000}s" }
                })
            } catch (e: Exception) {
                runOnUiThread {
                    makeButton.isEnabled = true
                    progress.visibility = View.GONE
                    status.text = "处理失败：${e.message}"
                }
            }
        }
    }

    private fun copyToCache(uri: Uri, prefix: String): File {
        val name = displayName(uri).replace(Regex("[^A-Za-z0-9._-]"), "_").take(60)
        val ext = name.substringAfterLast('.', "bin").takeIf { it.length <= 8 } ?: "bin"
        val file = File(cacheDir, "${prefix}_${System.nanoTime()}.$ext")
        contentResolver.openInputStream(uri)?.use { input ->
            file.outputStream().use { output -> input.copyTo(output) }
        } ?: throw IllegalStateException("无法读取所选文件")
        return file
    }

    private fun displayName(uri: Uri): String {
        val cursor = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            val index = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (index >= 0 && it.moveToFirst()) return it.getString(index) ?: "已选择文件"
        }
        return uri.lastPathSegment ?: "已选择文件"
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun lp(width: Int, height: Int) = LinearLayout.LayoutParams(width, height)

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
    }
}
