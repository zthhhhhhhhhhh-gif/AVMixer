# 音视频合成器（Android 项目源码）

## 当前功能
- 图片 + 音频：生成 30 fps 的 MKV 视频。
- 视频 + 音频：保留视频流，替换为所选音频流，输出 MKV。
- 使用 Android 系统文件选择器，选取任意文件后交给 FFmpeg 探测实际格式。
- 输出由系统“保存到”窗口选择位置。
- 所有处理在本机完成，不上传文件。

## 重要兼容性说明
“后缀不限”不等于所有文件都一定能解码。FFmpeg 根据文件内容探测容器和编码；损坏文件、加密文件、特殊编码或缺失解码器仍可能失败。
视频模式采用流复制（不重新编码），所以速度快且不损失质量，但所选音频/视频流能否装入 MKV 仍取决于 FFmpeg 对具体编码的支持。
图片模式将视频编码为 MPEG-4 Part 2，音频尽量直接复制。若音频编码与 MKV 不兼容，需改为 AAC 转码。
输出统一为 MKV，以尽量减少容器兼容性限制。

## 构建
1. 用 Android Studio 打开本文件夹。
2. 等待 Gradle 同步（需要网络下载 Gradle 插件和依赖）。
3. Build > Build Bundle(s) / APK(s) > Build APK(s)。
4. 安装生成的 APK。

最低 Android 7.0（API 24）；适用于 Android 13 的 Jelly Star（需设备为 arm64-v8a，当前依赖发布 arm64-v8a 和 x86_64）。

## 依赖
`dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.9`
这是社区维护的 FFmpegKit Android 分支；原 FFmpegKit 已停止维护。请在分发前核对依赖许可及其包含的编解码器。
